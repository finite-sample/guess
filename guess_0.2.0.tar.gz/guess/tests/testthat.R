library(testthat)
library(guess)

test_check("guess")
